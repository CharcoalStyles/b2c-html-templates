<template>
  <div class="flex flex-col min-h-screen max-w-screen antialiased text-base">
    <nsw-header :beta-banner="true" />
    <div class="flex-grow">
      <div class="xl:container">
        <div class="px-4 pb-8 md:px-6 md:pb-16">
          <slot />
        </div>
      </div>
    </div>
    <question-navigation :step-key="stepKey" />
    <div id="modal" />
  </div>
</template>

<script>
import NswHeader from '@/components/nsw/NswHeader'
import QuestionNavigation from '@/components/pathway/QuestionNavigation'
import { useMainStore } from '../store/index'

export default {
  components: {
    NswHeader,
    QuestionNavigation
  },
  setup() {
    const mainStore = useMainStore()

    return { mainStore }
  },
  computed: {

    /**
     * Generate step key to locate position in master sequence
     */
    stepKey() {
      return this.isChildStep()
        ? `${this.currentStep.id}-${this.currentChildStep().id}`
        : this.currentStep.id
    },

    /**
     * Current step based in url param id
     */
    currentStep() {
      if (this.$route.params.step) {
        return this.mainStore.getStepById(this.$route.params.step)
      } else {
        return {id: 'start'}
      }
      // return this.mainStore.getStepById(this.$route.params.step)
    },

    /**
     * Current step based on id
     */
    currentStepIndex() {
      return this.mainStore.getStepIndex(this.currentStep.id)
    },

    /**
     * Check if this step is the first
     */
    isFirstStep() {
      return this.currentStepIndex === 0
    },

    /**
     * Check if this step is the last
     */
    isLastStep() {
      return this.currentStepIndex === this.mainStore.filteredSteps.length - 1
    }
  },
  async mounted() {
    await Promise.all([
      this.mainStore.loadRoles(),
      this.mainStore.loadSkills(),
      this.mainStore.loadCapabilities()
    ])
  },
  methods: {
    isChildStep() {
      return this.$route.params.step && this.$route.params.id
    },

    /**
     * Current child step based in url param id
     */
    currentChildStep() {
      return this.mainStore.getChildStepById(
        this.$route.params.step,
        this.$route.params.id
      )
    }
  }
}
</script>
