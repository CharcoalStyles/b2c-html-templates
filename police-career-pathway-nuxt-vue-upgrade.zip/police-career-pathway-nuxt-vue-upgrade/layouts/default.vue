<template>
  <div class="flex flex-col min-h-screen max-w-screen antialiased text-base">
    <nsw-header :beta-banner="false" />
    <div class="flex-grow">
      <slot />
    </div>
    <nsw-footer />
    <div id="modal" />
  </div>
</template>

<script>
import NswHeader from '@/components/nsw/NswHeader'
import NswFooter from '@/components/nsw/NswFooter'
import { useMainStore } from '../store/index'

export default {
  setup() {
    const mainStore = useMainStore()

    return { mainStore }
  },
  computed: {
    test() {
      return this.mainStore.counter
    },
  },
  components: {
    NswHeader,
    NswFooter
  },
  async mounted() {
    await Promise.all([
      this.mainStore.loadRoles(),
      this.mainStore.loadSkills(),
      this.mainStore.loadCapabilities()
    ])
  }
}
</script>
