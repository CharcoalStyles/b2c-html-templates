import { defineNuxtConfig } from "nuxt/config"

export default defineNuxtConfig({
  // Disable server-side rendering
  ssr: false,

  // Target
  // target: 'static',

  telemetry: false,

  runtimeConfig: {
    public: {
      DEVELOPMENT_MODE: process.env.DEVELOPMENT_MODE,
      AI_CONNECTION_STRING: process.env.AI_CONNECTION_STRING
    }
  },

  router: {
    options: {
      scrollBehaviorType: 'smooth'
    }
  },

  // Global page headers
  app: {
    head: {
    title: 'NSW Police Career Pathways Tool',
    meta: [
      { charset: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      {
        hid: 'description',
        name: 'description',
        content:
          'Build and manage a digital career in NSW Government based on interests, capabilities, goals and past experiences.'
      }
    ],
    link: [
      { rel: 'icon', type: 'image/x-icon', href: '/favicon.ico' },
      {
        rel: 'stylesheet',
        href: 'https://fonts.googleapis.com/css2?family=Public+Sans:wght@400;600;700&display=swap'
      },
      {
        rel: 'stylesheet',
        href: 'https://cdn.jsdelivr.net/npm/nsw-design-system@2/dist/css/main.css'
      }
    ]
  }},

  // Global CSS
  css: [
    '~/assets/css/slider.css',
    '~/assets/css/transitions.css',
    '~/assets/css/tooltips.css'
  ],

  // Modules
  modules: ['@pinia/nuxt', 'pinia-plugin-persistedstate/nuxt', '@nuxtjs/tailwindcss', 'floating-vue/nuxt'],

  tailwindcss: {
    cssPath: ['~/assets/tailwind.css', { injectPosition: 'first' }]
  },

  vue: {
    compilerOptions: {
      // isCustomElement: (tag) => ['hero-section', 'feature-panel', 'section-container'].includes(tag),
    },
  },

  compatibilityDate: '2024-10-16',
})