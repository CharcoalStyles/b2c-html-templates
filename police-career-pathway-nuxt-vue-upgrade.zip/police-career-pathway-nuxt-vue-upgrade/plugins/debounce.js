import vueDebounce from 'vue-debounce'

export default defineNuxtPlugin((nuxtApp) => {
    nuxtApp.provide('debounce', vueDebounce)
})