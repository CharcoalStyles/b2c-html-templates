import collect from 'collect.js'

export default defineNuxtPlugin((nuxtApp) => {
  nuxtApp.provide('collect', collect)
})
