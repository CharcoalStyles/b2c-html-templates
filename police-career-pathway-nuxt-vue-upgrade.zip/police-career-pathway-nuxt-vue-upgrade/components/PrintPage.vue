<template>
  <button class="flex items-center underline font-bold print:hidden text-sm text-nsw-brand-primary-blue" style="text-underline-offset: 4px;">
    <img src="/saveCopy.svg" alt="Save a copy icon" class="mr-3">
    Save a copy
  </button>
</template>
