<template>
  <div class="inline">
    <popper hover arrow :options="tooltipOptions" :disabled="!tooltip">
      <template #content class="popper">
        {{ tooltip }}
      </template>
      <div slot="reference">
        <img src="/icons/help.svg" class="ml-2 shrink-0" alt="Help icon">
      </div>
    </popper>
    <!-- <VTooltip>
      <div>
        <img src="/icons/help.svg" class="ml-2 shrink-0" alt="Help icon">
      </div>

      <template #popper>
        {{ tooltip }}
      </template>
    </VTooltip> -->
  </div>
</template>

<script>
import Popper from "vue3-popper";

export default {
  components: {
    Popper
  },
  props: {
    tooltip: {
      type: String,
      default: ''
    }
  },
  computed: {
    tooltipOptions() {
      return {
        placement: 'bottom',
        modifiers: { offset: { offset: '0,5px' } }
      }
    }
  }
}
</script>
