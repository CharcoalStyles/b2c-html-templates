<template>
  <div class="lg:flex">
    <div class="lg:w-9/12">
      <div class="mb-8 md:mb-10">
        <h2 class="btn-blue font-bold text-nsw-brand-primary-blue mb-3">
          Career Planner
        </h2>
        <h1 class="text-3xl md:text-[42px] font-bold leading-tight mb-4">
          Get role suggestions to help you build a career plan
        </h1>
      </div>
      <div class="mb-6">
        <h2 class="text-2xl font-bold mb-3">How it works</h2>
        <ul class="ml-5 list-outside list-disc leading-loose lg:w-5/6">
          <li>We’ll ask a few questions about your skills, capabilities, interests and preferences</li>
          <li>We'll show you what roles might best suit you</li>
          <li>We’ll help you understand what you need to improve and develop</li>
          <li>We'll give you the information to guide your next career conversation</li>
        </ul>
      </div>
      <div class="mb-6">
        <h3 class="text-2xl font-bold mb-3">Who is this best suited for?</h3>
        <ul class="ml-5 list-outside list-disc leading-loose lg:w-5/6">
          <li>People looking for the next step in their career</li>
          <li>People looking for a change within NSWPF, but don't know where to start</li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
export default {}
</script>
