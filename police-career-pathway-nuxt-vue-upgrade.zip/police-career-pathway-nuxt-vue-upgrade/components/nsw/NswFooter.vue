<template>
  <footer class="bg-nsw-brand-primary-blue">
    <div class="w-full xl:container flex flex-col text-white">
      <div class="mt-8 mb-4 px-4 xl:px-0">
        <p class="text-xs">
          The NSW Police Force acknowledge First Nations peoples as the
          Traditional Owners and Custodians and pay respect to Elders past,
          present and to the future generations of Aboriginal peoples. NSW
          Police Force express sincere appreciation for the rich contribution of
          all Aboriginal and Torres Strait Islander Peoples.
        </p>
      </div>
      <hr class="w-full" />
      <div class="text-xs font-bold mt-4 mb-8 pl-4 xl:pl-0 flex flex-row flex-wrap gap-4">
        <a href="https://intranet.police.nsw.gov.au/home_page/copyright_and_disclaimer" target="_blank" class="underline">
          Copyright
        </a>
        <a href="https://intranet.police.nsw.gov.au/law/privacy_code_of_practice" target="_blank" class="underline">
          Privacy
        </a>
        <!-- <a href="https://intranet.police.nsw.gov.au/organisational_units/corporate_services/human_resource_services/careers_and_deployment/career_planning_and_development_framework/career_" target="_blank" class="underline">
          Contact us
        </a> -->
      </div>
      <p class="text-xs mb-8 pl-4 xl:pl-0">Copyright © 2024</p>
    </div>
  </footer>
</template>

<script>
export default {}
</script>
<style></style>
