<template>
  <div class="p-4 md:p-6 flex flex-col md:flex-row items-start md:items-center xl:container text-sm">
    <div class="px-2 h-6 mb-2 md:mb-0 flex items-center justify-center text-white font-bold bg-nsw-brand-primary-blue mr-3 leading-none whitespace-no-wrap">
      New Service
    </div>
    <span class="md:text-base">Please <a href="https://forms.office.com/Pages/ResponsePage.aspx?id=aHr5Hqvo7UShbbV5_i182IXKpD-zbx9LsP29enYEDpdUOUM4UkhFTVpWR1NDN0lBMFVSUThRRVhUMS4u" target="_blank" class="underline">leave your feedback</a> to help us improve the service.</span>
  </div>
</template>
