<template>
  <div class="inline h-6 bg-green-200 flex items-center font-semibold px-4 rounded-full text-gray-800">
    Emerging role
  </div>
</template>
