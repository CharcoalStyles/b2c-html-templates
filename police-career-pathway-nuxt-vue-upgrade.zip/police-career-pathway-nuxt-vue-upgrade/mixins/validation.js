import { useMainStore } from '../store/index'

export default {
  setup() {
    const mainStore = useMainStore()

    return { mainStore }
  },
  methods: {
    isStepDisabled(step) {
      // Only apply on question steps
      if (step && step.type === 'question' && step.schema.field.required === true) {
        // Does the step exist in answers
        return !this.mainStore.pathway.answers[step.id]?.value
      }
      return false
    },
    isChildStepDisabled(step) {
      if (step.schema.field.type === 'skill') {
        const value = this.mainStore.pathway.answers.skills?.[step.id]?.value
        if (Number.isInteger(value) && value > -1) {
          return false
        }
      } else {
        const value = this.mainStore.pathway.answers.capabilities?.[step.id]?.value
        if (Number.isInteger(value) && value > -1) {
          return false
        }
      }
      return true
    }
  }
}
