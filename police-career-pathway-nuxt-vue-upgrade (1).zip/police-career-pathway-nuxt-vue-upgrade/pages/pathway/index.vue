<template>hi</template>
<script>
import { useMainStore } from '../store/index'
export default {
  setup() {
    definePageMeta({
      layout: 'pathway',
      middleware: 'step'
    })

    const mainStore = useMainStore()

    return { mainStore }
  },
}
</script>
