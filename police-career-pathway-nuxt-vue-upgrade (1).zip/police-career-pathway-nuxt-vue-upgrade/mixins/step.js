import { useMainStore } from '../store/index'

export default {
  setup() {
    const mainStore = useMainStore()

    return { mainStore }
  },
  computed: {
    /**
     * Current step based in url param id
     */
    currentStep() {
      return this.mainStore.getStepById(this.$route.params.step)
    },
    /**
     * Current step based on id
     */
    currentStepIndex() {
      if (this.currentStep) {
        return this.mainStore.getStepIndex(this.currentStep.id)
      } else {
        return 0
      }
    },
    /**
     * Check if this step is the first
     */
    isFirstStep() {
      return this.currentStepIndex === 0
    },
    /**
     * Check if this step is the last
     */
    isLastStep() {
      return this.currentStepIndex === this.mainStore.filteredSteps.length - 1
    }
  }
}
