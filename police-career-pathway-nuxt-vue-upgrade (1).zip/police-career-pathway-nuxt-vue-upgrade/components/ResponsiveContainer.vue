<template>
  <div class="flex flex-col md:flex-row md:py-12 xl:container">
    <div class="px-4 md:px-6 w-full">
      <slot />
    </div>
  </div>
</template>
