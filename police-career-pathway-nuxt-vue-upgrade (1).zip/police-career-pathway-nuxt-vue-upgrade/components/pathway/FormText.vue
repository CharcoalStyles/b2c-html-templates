<template>
  <div>
    <input-text v-model="answer" :step="step" />
  </div>
</template>

<script>
import InputText from '@/components/forms/InputText'
import { useMainStore } from '../store/index'

export default {
  components: {
    InputText
  },
  props: {
    step: {
      type: Object,
      required: true
    }
  },
  setup() {
    const mainStore = useMainStore()

    return { mainStore }
  },
  computed: {
    answer: {
      get() {
        return this.mainStore.pathway.answers?.[this.step.id]?.value ?? ''
      },
      set(value) {
        this.mainStore.saveQuestionAnswer({
          id: this.step.id,
          value
        })
      }
    }
  }
}
</script>
