<template>
  <div class="h-8 w-8 rounded-full inline-flex items-center justify-center bg-nsw-brand-psc-purple text-white text-lg font-bold mr-5">
    <slot />
  </div>
</template>
