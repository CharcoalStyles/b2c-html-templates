import { useMainStore } from '../store/index'

export default defineNuxtRouteMiddleware((to, from) => {
  const mainStore = useMainStore()
  const firstStep = mainStore.pathway.steps[0]
  return navigateTo(`/pathway/${firstStep.id}`)
})
