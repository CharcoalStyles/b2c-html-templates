<template>
  <div>
    <div id="modal" />
    <slot />
  </div>
</template>

<script>
import { useMainStore } from '../store/index'
export default {
  setup() {
    const mainStore = useMainStore()

    return { mainStore }
  },

  async mounted() {
    await Promise.all([
      this.mainStore.loadRoles(),
      this.mainStore.loadSkills(),
      this.mainStore.loadCapabilities()
    ])
  }
}
</script>
