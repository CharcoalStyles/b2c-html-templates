<template>
  <div class="flex flex-col min-h-screen antialiased text-base">
    <div class="bg-nsw-grey-100 block h-header absolute z-0" />
    <nsw-header />
    <slot />
    <nsw-footer />
    <div id="modal" />
  </div>
</template>

<script>
import NswHeader from '@/components/nsw/NswHeader'
import NswFooter from '@/components/nsw/NswFooter'
import { useMainStore } from '../store/index'

export default {
  components: {
    NswHeader,
    NswFooter
  },
  setup() {
    const mainStore = useMainStore()

    return { mainStore }
  },
  async mounted() {
    await Promise.all([
      this.mainStore.loadRoles(),
      this.mainStore.loadSkills(),
      this.mainStore.loadCapabilities()
    ])
  }
}
</script>
